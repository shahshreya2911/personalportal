
<div class="row">
    <div class="col-md-6">
        <input type="hidden" name="productid" value="{{ $product->id ? $product->id : '' }}">
        <div class="form-group">
            <label for="first_name">Product Name</label>
            <input type="text" class="form-control" id="productname"
                   name="productname" placeholder="Product Name" value="{{ $product->productname ? $product->productname : '' }}">
        </div>
         <div class="form-group">
           <label for="first_name">Brand Name</label>
            <input type="text" class="form-control" id="brandname"
                   name="brandname" placeholder="Brand Name" value="{{  $product->brandname ? $product->brandname : '' }}">
        </div>
         <table class="table table-bordered" id="dynamicTable">  
           
          
         @if(count($pro_attr))
             @foreach ($pro_attr as $attr)
               <tr>  
                <td><input type="text" name="addmore[{{$loop->index}}][name]" value="{{ $attr->name ? $attr->name : '' }}" placeholder="Enter Attribute Name" class="form-control" /></td>  
                <td><input type="text" name="addmore[{{$loop->index}}][description]" placeholder="Enter Attribute Desc" value="{{ $attr->description ? $attr->description : '' }}" class="form-control" /></td>  
               
                <td><button type="button" name="add" id="add" class="btn btn-success add">Add More</button></td>  
                </tr>  
             @endforeach
             @endif
            <input type="hidden" name="countadmore" value="{{ count($pro_attr) }}" id="countadmore">   
        </table> 
        <div class="form-group">
             <label for="first_name">Note</label>
            <input type="text" class="form-control" id="notes"
                  name="notes" placeholder="Note" value="{{  $product->notes ? $product->notes : '' }}">
        </div>
        
   
</div>
        
    <div class="col-md-6">
         
     
    </div>

    @if ($edit)
        <div class="col-md-12 mt-2">
            <button type="submit" class="btn btn-primary" id="update-details-btn">
                <i class="fa fa-refresh"></i>
                @lang('app.update_details')
            </button>
        </div>
    @endif
</div>
